"""CLI module for agent_framework."""

from .main import main, init_project

__all__ = ["main", "init_project"]
