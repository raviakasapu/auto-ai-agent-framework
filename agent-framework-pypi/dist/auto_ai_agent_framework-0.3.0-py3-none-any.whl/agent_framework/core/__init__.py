# Core orchestrator and event system

